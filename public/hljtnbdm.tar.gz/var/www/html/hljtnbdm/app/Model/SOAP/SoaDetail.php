<?php
/**
 * Created by PhpStorm.
 * User: purplebleed
 * Date: 2015/9/30
 * Time: 下午 11:18
 */

namespace App\Model\SOAP;
use Illuminate\Database\Eloquent\Model;

class SoaDetail extends Model
{
    protected $table = 'soa_detail';

    protected $primaryKey = 'soa_detail_pk';

}