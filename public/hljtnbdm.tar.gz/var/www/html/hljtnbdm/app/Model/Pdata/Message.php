<?php namespace App\Model\Pdata;

/**
 * Created by PhpStorm.
 * User: purplebleed
 * Date: 2015/9/24
 * Time: 上午 01:30
 */

use Illuminate\Database\Eloquent\Model;

class Message extends Model
{
    protected $table = 'message';

    protected $primaryKey = 'message_pk';

}
