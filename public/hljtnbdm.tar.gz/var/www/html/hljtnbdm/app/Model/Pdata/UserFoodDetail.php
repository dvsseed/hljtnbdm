<?php
/**
 * Created by PhpStorm.
 * User: purplebleed
 * Date: 2015/10/1
 * Time: 下午 10:25
 */

namespace App\Model\Pdata;

use Illuminate\Database\Eloquent\Model;

class UserFoodDetail extends Model
{
    protected $table = 'user_food_detail';

    protected $primaryKey = 'user_food_detail_pk';

}