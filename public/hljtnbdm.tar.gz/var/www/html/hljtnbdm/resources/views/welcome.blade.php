@extends('master')

@section('content')
	<div class="container">
		<div class="jumbotron">
			<!-- h2><div class="quote">{{-- Inspiring::quote() --}}</div></h2 -->
			<p>黑龙江瑞京糖尿病医院共同照护管理系统</p>
			<p>使用若有疑问请咨询管理员</p>
			<p><a class="btn btn-primary btn-lg" href="/login" role="button">请登录</a></p>
		</div>
	</div>
@stop
