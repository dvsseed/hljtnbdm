@extends('master')

@section('title')
    血糖資料
@stop

@section('content')

    <div class="container">
        {{$err_msg}}
    </div>

@stop
