@extends('layout')

@section('title')
	方案管理
@stop

@section('pactive')
    active
@stop

@section('navstr')
    <a href="/case">方案资料</a>
@stop

@section('navabout')
    /aboutcase
@stop

@section('content')
    <div class="page-header">
        <h3>方案管理</h3>
    </div>
<h3>施工中...</h3>coming soon

@endsection
