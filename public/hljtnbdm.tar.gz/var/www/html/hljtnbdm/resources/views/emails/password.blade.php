请点击此处重设密码: {{ url('password/reset/'.$token) }}
