<?php

return [

	/*
	|--------------------------------------------------------------------------
	| Password Reminder Language Lines
	|--------------------------------------------------------------------------
	|
	| The following language lines are the default lines which match reasons
	| that are given by the password broker for a password update attempt
	| has failed, such as for an invalid token or invalid new password.
	|
	*/

	"password" => "密码的匹配必须确认至少三个字符。",
	"user" => "我们无法找到与该电子邮件地址的用户。",
	"token" => "This password reset token is invalid.",
	"sent" => "We have e-mailed your password reset link!",
	"reset" => "Your password has been reset!",

];
