$(function () {
    $('[data-toggle="popover"]').popover();
    $('div.alert').delay(2500).slideUp(300);
    // $("#sortTable").tablesorter();
});
